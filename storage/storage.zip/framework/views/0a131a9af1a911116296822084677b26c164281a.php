
<?php $__currentLoopData = $tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $dash = ($value['parent'] == 0) ? '' : str_repeat('-', $r) .' '; ?>

    <option value="<?php echo e($value['id'], false); ?>"><?php echo e($dash, false); ?><?php echo e($value['title'], false); ?></option>

    <?php if($value['parent'] == $p): ?>
        <?php $r = 0; ?>
    <?php endif; ?>

    <?php if(isset($value['_children'])): ?>
        <?php echo $__env->make('admin.menus.includes.navigationSelectParentMenu', ['tree' => $value['_children'], 'r' => $r+1, $p => $value['parent']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH D:\OpenServer\domains\investments\resources\views/admin/menus/includes/navigationSelectParentMenu.blade.php ENDPATH**/ ?>