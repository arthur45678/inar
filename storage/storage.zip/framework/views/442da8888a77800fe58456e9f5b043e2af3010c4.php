<div class="row clearfix">
    <br>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger">
                <strong><?php echo e(Session::get('fail'), false); ?></strong>
            </div>
        <?php endif; ?>

        <?php if(Session::has('warning')): ?>
            <div class="alert alert-danger">
                <strong><?php echo e(Session::get('warning'), false); ?></strong>
            </div>
        <?php endif; ?>

        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <strong><?php echo e(Session::get('success'), false); ?></strong>
            </div>
        <?php endif; ?>
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error, false); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
</div>





<?php /**PATH D:\OpenServer\domains\investments\resources\views/admin/includes/info-box.blade.php ENDPATH**/ ?>