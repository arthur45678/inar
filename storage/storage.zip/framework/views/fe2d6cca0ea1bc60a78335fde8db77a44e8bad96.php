<?php if(isset($item['_children'])): ?>
    <?php if($firstParentElement == true): ?>
        <li class="shrift-normal">
            <a  href="<?php echo e($item['path'], false); ?>"  id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e($item['title'], false); ?></a>
            <ul >
                <?php $__currentLoopData = $item['_children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('site.includes.menu_header_navigation', ['firstParentElement' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
    <?php else: ?>
        <li class="shrift-normal">
            <a  href="<?php echo e($item['path'], false); ?>"><?php echo e($item['title'], false); ?></a>
            <ul >
                <?php $__currentLoopData = $item['_children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('site.includes.menu_header_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
    <?php endif; ?>
<?php else: ?>
    <li class="shrift-normal has-sub">
        <a  href="<?php echo e($item['path'], false); ?>"><?php echo e($item['title'], false); ?></a>
    </li>
<?php endif; ?>

<?php /**PATH D:\OpenServer\domains\investments\resources\views/site/includes/menu_header_navigation.blade.php ENDPATH**/ ?>