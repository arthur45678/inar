

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.info-box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>

        <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
            <div class="container">
                <div class="page-header-content pt-4">
                    <div class="row align-items-center justify-content-between">
                        <div class="col-auto mt-4">
                            <h1 class="page-header-title">
                                <div class="page-header-icon"><i data-feather="filter"></i></div>
                                <?php echo e($title, false); ?>

                            </h1>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main page content-->
        <div class="container mt-n10">
            <div class="card mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e($title, false); ?></h6>

                    <!-- <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($lang == $localeCode): ?>
                            Menu for <strong><?php echo e($properties['native'], false); ?></strong> language
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo e(route('admin.menus.store'), false); ?>" enctype="multipart/form-data">
                        <input type="hidden" name="lang" value="<?php echo e($lang, false); ?>">
                        <?php echo e(csrf_field(), false); ?>



                        <div class="form-group">
                            <label for="parent">Ներդրման կարգը</label>
                            <select name="parent" id="parent" class="form-control">
                                <option value="0">Գլխավոր մենյու</option>
                                <?php echo $__env->make('admin.menus.includes.navigationSelectParentMenu', ['tree' => $data['parents'],  $r = 0, $p = null], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </select>
                        </div>


                        <div class="form-group">
                            <label for="title">Անուն</label>
                            <input type="text" name="title" id="title" value="<?php echo e(old('title'), false); ?>" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="path">Հղում (Կարող եք ընտրել մենյուից կամ ուղակի հղում դնել)</label>
                            <input type="url" name="path" id="path" value="<?php echo e(old('path'), false); ?>" class="form-control">
                        </div>

                        <div class="col-md-4">
                            <button class="item-name btn btn-primary">Ստեղծել</button>
                        </div>
                    </form>
                </div>

            </div>

        </div>
    </main>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\investments\resources\views/admin/menus/create.blade.php ENDPATH**/ ?>