
<?php $__currentLoopData = $tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $dash = ($value['parent'] == 0) ? '' : str_repeat('-', $r) .' '; ?>

    <tr>
        <td><?php echo e($dash, false); ?><?php echo e($value['title'], false); ?></td>
        <td><?php echo e(isset($value['path']) ? $value['path'] : '', false); ?></td>
        <td>
            <form method="post" action="<?php echo e(route('admin.menus.destroy',[$value['id']]), false); ?>">
                <input type="hidden" name="_method" value="delete">
                <?php echo e(csrf_field(), false); ?>


                <div class="form-group">
                    <button type="submit" class="btn btn-danger">Delete</button>
                </div>
            </form>
        </td>
    </tr>
    <?php if($value['parent'] == $p): ?>
        <?php $r = 0; ?>
    <?php endif; ?>

    <?php if(isset($value['_children'])): ?>
        <?php echo $__env->make('admin.menus.includes.navigationMenuTable', ['tree' => $value['_children'], 'r' => $r+1, $p => $value['parent']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH D:\OpenServer\domains\investments\resources\views/admin/menus/includes/navigationMenuTable.blade.php ENDPATH**/ ?>