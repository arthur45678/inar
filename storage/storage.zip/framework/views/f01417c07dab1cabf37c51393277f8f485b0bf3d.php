


<?php $__env->startSection('title'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_keywords',getAppNameLocale()); ?>
<?php $__env->startSection('meta_description', getAppNameLocale()); ?>

<?php $__env->startSection('styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('site.includes.info-box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="buisness">

        <div class="left-container">
            <?php if(isset($post->page_img)): ?>
                <img src="<?php echo e(showImage($post->page_img), false); ?>" alt="<?php echo e($post->name, false); ?>" class="zoom" />

            <?php endif; ?>
        </div>
        <div class="right-container">
            <div class="page-name"><?php echo e($post->name, false); ?></div>
            <?php if(isset($post->page_img_mini)): ?>
                <img src="<?php echo e(showImage($post->page_img_mini), false); ?>" alt="<?php echo e($post->name, false); ?>" />

            <?php endif; ?>
        </div>
    </div>

  
    <div class="main-info">
        <?php if(isset($post->text_top) && !empty($post->text_top)): ?>
            <div class="info-right">
                <div><?php echo $post->text_top; ?></div>
                <img src="<?php echo e($assetPath, false); ?>/css/icons-images/mission-fon.svg" alt="fon" />
            </div>
        <?php if(isset($post->page_img_middle) && !empty($post->page_img_middle)): ?>
                <div style="background-image: url(<?php echo e(showImage($post->page_img_middle), false); ?>)" class="main-justify back back-4"></div>
            <?php endif; ?>

        <?php endif; ?>
        <?php if(isset($post->text_middle) && !empty($post->text_middle)): ?>
            <div class="info-left">
                <img src="<?php echo e($assetPath, false); ?>/css/icons-images/mission-fon.svg" alt="fon" />
                <div><?php echo $post->text_middle; ?></div>
            </div>
        <?php endif; ?>
    </div>

    <?php if(isset($post->text_bottom) && !empty($post->text_bottom)): ?>
        <div class="main-info-enviroment talent">
            <?php echo $post->text_bottom; ?>

        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('site.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\investments\resources\views/site/pages/talents/show.blade.php ENDPATH**/ ?>