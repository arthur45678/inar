


<?php $__env->startSection('styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('site.includes.info-box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($post->categories()->first()): ?>
        <div class="top-container">
            <div class="news-anun"><a href="<?php echo e(route('categoryPosts',[$post->categories()->first()->slug]), false); ?>"><?php echo e($post->categories()->first()->name, false); ?></a></div>
            <?php if(isset($post->categories()->first()->page_img)): ?>
                <img src="<?php echo e(showImage($post->categories()->first()->page_img), false); ?>" alt="<?php echo e($post->categories()->first()->name, false); ?>" />
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="post">
        <h1><?php echo e($post->name, false); ?></h1>
        <?php if(isset($post->img)): ?>
            <img src="<?php echo e(showImage($post->img), false); ?>" alt="" />
        <?php endif; ?>

       <?php echo $post->text; ?>




        <?php if($post->tags()->count() > 0): ?>
            <p>Tags</p>
            <?php $__currentLoopData = $post->tags()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('tagPosts',[$tag->slug]), false); ?>">#<?php echo e($tag->name, false); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>

        <?php endif; ?>


    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('site.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\investments\resources\views/site/articles/show.blade.php ENDPATH**/ ?>