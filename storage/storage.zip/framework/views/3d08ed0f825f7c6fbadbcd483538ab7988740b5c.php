


<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('asset/site/css/index.css'), false); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('asset/site/css/owl.theme.default.css'), false); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('asset/site/css/owl.carousel.min.css'), false); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('asset/site/js-plugins/owl.carousel.min.js'), false); ?>"></script>
    <script src="<?php echo e(asset('asset/site/js-plugins/rellax.min.js'), false); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('site.includes.info-box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--  -->
    <!--    Slider-->
    <!--    -->

    <?php if(isset($sliders) && $sliders->count() > 0): ?>
        <div class="slider-carousel owl-carousel parallax" data-rellax-speed="-7">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <div class="slide-text">
                    <p><?php echo e($item->name, false); ?></p>
                    <p><?php echo e($item->desc, false); ?></p>
                    <a href="<?php echo e($item->link, false); ?>" class="btn"><?php echo e($item->link_name, false); ?></a>
                </div>
                <?php if(isset($item->img)): ?>
                    <img src="<?php echo e(showImage($item->img), false); ?>" alt="" />

                <?php endif; ?>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    <?php endif; ?>



    <!-- -->
    <!--Our mission-->
    <!-- -->

    <div class="our-mission">
        <img src='<?php echo e(asset('asset/site/css/icons-images/mission-fon.svg'), false); ?>' alt="" />
        <div class="mission-info">
            <div>
                <h2>OUR MISSION</h2>
                <p><?php echo e(settings()->group(App::getLocale())->get('ourMissionsPage_description'), false); ?></p>
            </div>
        </div>
        <div>
            <div class="mission-containers">
                <?php $__currentLoopData = $ourMissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <img src="<?php echo e(showImage($item->img), false); ?>" alt="<?php echo e($item->title, false); ?>" />
                        <p><a href=""><?php echo e($item->title, false); ?></a></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <img src="<?php echo e(asset('asset/site/css/icons-images/Inv-promotion.png'), false); ?>" alt="" />
                    <p>Investment Promotion</p>
                </div>
                <div class="mission_center">
                    <img src="<?php echo e(asset('asset/site/css/icons-images/check.svg'), false); ?>" alt="" />
                    <p>Made in Armenia</p>
                </div>
                <div>
                    <img src="<?php echo e(asset('asset/site/css/icons-images/inv-aftercare.png'), false); ?>" alt="" />
                    <p>Investment Aftercare</p>
                </div>
            </div>
        </div>
    </div>

    <!--    -->
    <!--News-->
    <!-- -->

    <div class="tweets-block">
        <div class="tweets">
            <div class="left-content">
                <div class="head-info">
                    <!-- <h2><?php echo e(__('home.latest_news'), false); ?></h2> -->
                    <h2><?php echo e(__('latest news'), false); ?></h2>
                    <div class="by">
                        <span class='name'>Tweets</span>
                        <span>by &copy;EnterpriceAM</span>
                        <span class="info-icon">
                            <img src="<?php echo e(asset('asset/site/css/icons-images/info.svg'), false); ?>" alt="info" />
                            </span>
                    </div>
                </div>
                <div class="info-content-left">
                    <div class='news-item'>
                        <div class='news-logo'>
                            <img src="<?php echo e(asset('asset/site/css/icons-images/sm-logo.png'), false); ?>" alt="" />
                        </div>
                        <div class="news-info">
                            <div>
                                <span class="news-name">Enterprice Armenia</span>
                                <span class="nuyn">@EnterpriceAM</span>
                                <span class="nuyn nuyn-data">1 dec 2020</span>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque similique eos reprehenderit tempora rerum vel corporis non odio pariatur minus.</p>
                            <div class='news-img'>
                                <img src="<?php echo e(asset('asset/site/css/icons-images/wine.png'), false); ?>" alt="wine" />
                            </div>
                            <div class="exit">
                                <span>
                                    <i class="far fa-heart"></i>
                                </span>
                                <span>
                                    <i class="fas fa-sign-out-alt"></i>
                                </span>
                            </div>
                        </div>
                        <div class="ellipsis">
                            <i class="fas fa-ellipsis-h"></i>
                        </div>
                    </div>
                    <div class='news-item'>
                        <div class='news-logo'>
                            <img src="<?php echo e(asset('asset/site/css/icons-images/sm-logo.png'), false); ?>" alt="" />
                        </div>
                        <div class="news-info">
                            <div>
                                <span class="news-name">Enterprice Armenia</span>
                                <span class="nuyn">@EnterpriceAM</span>
                                <span class="nuyn nuyn-data">1 dec 2020</span>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque similique eos reprehenderit tempora rerum vel corporis non odio pariatur minus.</p>
                            <div class='news-img'>
                                <img src="<?php echo e(asset('asset/site/css/icons-images/wine.png'), false); ?>" alt="wine" />
                            </div>
                            <div class="exit">
                                <span>
                                    <i class="far fa-heart"></i>
                                </span>
                                <span>
                                    <i class="fas fa-sign-out-alt"></i>
                                </span>
                            </div>
                        </div>
                        <div class="ellipsis">
                            <i class="fas fa-ellipsis-h"></i>
                        </div>
                    </div>
                </div>
                <div class="tweets-footer">
                    <span class="embed">Embed</span>
                    <span class="view">View in Twitter</span>
                </div>
            </div>
            <div class="right-content">
                <div class="head-info">
                    <!-- <h2><?php echo e(__('home.upcoming_events'), false); ?></h2> -->
                    <h2><?php echo e(__('upcoming events'), false); ?></h2>
                    <div class="by">
                        <span class="name">Events</span>
                        <span>by &copy;EnterpriceAM</span>
                    </div>
                </div>
                <div class="info-content-right">

                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php $math=\Carbon\Carbon::parse($event->event_started_date)->format('m') ?>

                    <div class="event">
                        <div class="event-img">
                            <div class="data-logo">
                                <img src="<?php echo e(asset('asset/site/css/icons-images/data-logo.png'), false); ?>" alt="data" class="data-image" />
                                <div><?php echo e(\Carbon\Carbon::parse($event->event_started_date)->format('d'), false); ?>

                                    <?php echo app('translator')->get('lang.math_'.$math); ?></div>
                            </div>
                            <img src="<?php echo e(showImage($event->img_mini), false); ?>" alt="man" class="event-image" />
                        </div>

                        <div class="event-info">
                            <h3><?php echo e($event->getTranslation('name', App::getLocale()) ?? ' ', false); ?></h3>
                            <span><?php echo e($event->getTranslation('desc', App::getLocale()) ?? ' ', false); ?></span>
                            <p class="learn-more" onclick="location.href='<?php echo e(route('site.calendar.show',$event->id), false); ?>'" style="cursor: pointer;"><?php echo app('translator')->get('lang.Learn more'); ?></p>
                        </div>
                    </div>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <div class="tweets-footer">
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </div>

    <!---->
    <!--Discoer-->
    <!---->

    <div class="discover_armenia_block">
        <!-- <h2 class="discover_armenia"><?php echo e(__('home.dyscovery_armenia'), false); ?></h2> -->
        <h2 class="discover_armenia"><?php echo e(__('discover armenia'), false); ?></h2>
    </div>
    <div class="slider-discover owl-carousel owl-theme">
        <?php $__currentLoopData = $discoveryArmenia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <div class="discover">
                    <div class="discover_img">
                        <img src="<?php echo e(showImage($item->img), false); ?>" alt="<?php echo e($item->name, false); ?>" />
                    </div>
                    <div class="discover_info">
                        <div>
                            <h2><?php echo e($item->name, false); ?></h2>
                            <p><?php echo e($item->desc, false); ?></p>

                            <?php if(isset($item->file)): ?>
                                <div>

                                    <!-- <a href="<?php echo e(route('site.showPdf',['pdfFileName' => $item->file]), false); ?>" class="button"><?php echo e(__('home.read'), false); ?></a> -->
                                    <a href="<?php echo e(route('site.showPdf',['pdfFileName' => $item->file]), false); ?>" class="button"><?php echo e(__('View Brochure'), false); ?></a>
                                    <!-- <a href="<?php echo e(getFile($item->file), false); ?>" class="button"><?php echo e(__('home.download'), false); ?></a> -->
                                    <a href="<?php echo e(getFile($item->file), false); ?>" class="button"><?php echo e(__('Download'), false); ?></a>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('site.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\investments\resources\views/site/home.blade.php ENDPATH**/ ?>