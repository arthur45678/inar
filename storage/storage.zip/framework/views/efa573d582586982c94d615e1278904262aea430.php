<?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <a  hidden rel="alternate" id="lang<?php echo e($localeCode, false); ?>" hreflang="<?php echo e($localeCode, false); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true), false); ?>">
            <?php echo e($properties['native'], false); ?>

        </a>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<header class="parallax" data-rellax-speed="-5">
    <div class="covid">
        <div class="updates-names">COVID 19 UPDATES</div>
        <div class="instruments">
            <img src="<?php echo e(asset('asset/site/css/icons-images/search.svg'), false); ?>" alt="Enterprice-armenia" />
            <select onchange="document.getElementById('lang'+this.value).click()">
                <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($localeCode==app()->getLocale()): ?>
                <option value="<?php echo e($localeCode, false); ?>" selected><?php echo e($properties['names'], false); ?></option>
                    <?php else: ?>
                <option value="<?php echo e($localeCode, false); ?>"><?php echo e($properties['names'], false); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>


            <?php if(Route::has('login')): ?>

                    <?php if(auth()->guard()->check()): ?>
                    <button onclick="location.href='<?php echo e(route('home'), false); ?>'">Sign In</button>
                    <?php else: ?>
                    <button onclick="location.href='<?php echo e(route('login'), false); ?>'">Sign In</button>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="search-panel">
            <i class="fas fa-search"></i>
            <input type="search" />
            <i class="fas fa-times"></i>
        </div>
    </div>
    <div class="menu-content">
        <div class="aaa">
            <img src="<?php echo e(asset('asset/site/css/icons-images/logo.svg'), false); ?>" alt="search-button" onclick="location.href='<?php echo e(route('site.index'), false); ?>'" />
            <div class="menu-container">
                <div class="stellarnav" style="padding:0px">
                    <ul>

<!--
                        <li class="shrift-normal"><a href="#">Armenia</a>
                            <ul>
                                <li><a href="<?php echo e(route('site.talent'), false); ?>">Talent</a></li>
                                <li><a href="<?php echo e(route('site.buisness'), false); ?>">Buisness Enviroment</a></li>
                                <li><a href="<?php echo e(route('site.quality'), false); ?>">Quality and costs</a></li>
                                <li><a href="<?php echo e(route('site.infrastructure'), false); ?>">Infrastructure</a></li>
                                <li><a href="<?php echo e(route('site.innovation'), false); ?>">Innovation and R&D</a></li>
                                <li><a href="<?php echo e(route('site.lifestyle'), false); ?>">Lifestyle</a></li>
                            </ul>
                        </li>

-->


                        <?php $__currentLoopData = $menu_tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('site.includes.menu_header_navigation', ['item' => $item, 'dropdownMenuLink_id' => 0, 'firstParentElement' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </ul>
                </div>
                <button>HOW TO REACH US</button>
            </div>
        </div>
    </div>
</header>
<?php /**PATH D:\OpenServer\domains\investments\resources\views/site/includes/header.blade.php ENDPATH**/ ?>