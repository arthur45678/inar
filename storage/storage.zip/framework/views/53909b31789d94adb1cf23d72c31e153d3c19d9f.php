


<?php $__env->startSection('title'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_keywords',getAppNameLocale()); ?>
<?php $__env->startSection('meta_description', getAppNameLocale()); ?>

<?php $__env->startSection('styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('site.includes.info-box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="buisness">  

        <div class="left-container">
            <?php if(!empty($post->page_img) && isset($post->page_img)): ?>
                <img src="<?php echo e(showImage($post->page_img), false); ?>" alt="<?php echo e($post->name, false); ?>" class="zoom" />

            <?php endif; ?>
        </div>
        <div class="right-container">
            <div class="page-name"><?php echo e($post->name, false); ?></div>
            <?php if(!empty($post->page_img_mini) && isset($post->page_img_mini)): ?>
                <img src="<?php echo e(showImage($post->page_img_mini), false); ?>" alt="<?php echo e($post->name, false); ?>" />

            <?php endif; ?>
        </div>
    </div>
    <div class="page-link">
        <span class="first"><?php echo e($post->name, false); ?></span>

    </div>

    <div class="main-info">
        <?php if(!empty($post->text_top) && isset($post->text_top)): ?>
            <div class="info-right">
                <div><?php echo $post->text_top; ?></div>
                <img src="<?php echo e($assetPath, false); ?>/css/icons-images/mission-fon.svg" alt="fon" />

            </div>
        <?php endif; ?>
        <?php if(!empty($post->page_img_top) && isset($post->page_img_top)): ?>
            <div style="background-image:url(<?php echo e(showImage($post->page_img_top), false); ?>)" class="main-justify back">
        <?php endif; ?>
        </div>
        
            <?php if(!empty($post->text_middle) && isset($post->text_middle)): ?>
            <div class="info-left">
                <img src="<?php echo e($assetPath, false); ?>/css/icons-images/mission-fon.svg" alt="fon" />
                <div><?php echo $post->text_middle; ?></div>
            </div>
            <?php endif; ?>
            <?php if(!empty($post->img_middle) && isset($post->img_middle)): ?>
                <div style="background-image:url(<?php echo e(showImage($post->page_img_middle), false); ?>)" class="main-justify back "></div>

            <?php endif; ?>

            <?php if(!empty($post->text_bottom) && isset($post->text_bottom) ): ?>
    
                <div class="info-right">
                    <div><?php echo $post->text_bottom; ?></div>
                    <img src="<?php echo e($assetPath, false); ?>/css/icons-images/mission-fon.svg" alt="fon" />
                </div>
             
            <?php endif; ?>

            <?php if(!empty($post->page_img_bottom) && isset($post->page_img_bottom)): ?>
                <div style="background-image:url(<?php echo e(showImage($post->page_img_bottom), false); ?>)" class="main-justify back">
            <?php endif; ?>

    
    </div>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('site.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\investments\resources\views/site/pages/simples/show.blade.php ENDPATH**/ ?>