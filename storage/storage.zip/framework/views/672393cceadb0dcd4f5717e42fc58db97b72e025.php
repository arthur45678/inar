<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.7">
    <link rel="icon" type="image/x-icon" href="<?php echo e($assetPath, false); ?>/css/icons-images/logo.svg" />

    <link rel="stylesheet" href="<?php echo e($assetPath, false); ?>/css/second-pages.css" />
    <link rel="stylesheet" href="<?php echo e(asset('asset/site/css/header-footer.css'), false); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('asset/site/css/fonts/font-awesome/css/all.min.css'), false); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('asset/site/css/stellarnav.min.css'), false); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/site/css/index.css'), false); ?>">

    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords','some default keywords'); ?>">
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description','default description'); ?>">
    <link rel="canonical" href="<?php echo e(url()->current(), false); ?>"/>
    <title><?php echo $__env->yieldContent('title',config('app.name')); ?></title>

    <?php echo $__env->yieldContent('styles'); ?>

<!--Start of Tawk.to Script-->
    <script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/600038fcc31c9117cb6e9121/1es0dt6st';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
    <!--End of Tawk.to Script-->

</head>
<body>
<?php echo $__env->yieldContent('header'); ?>



<?php echo $__env->yieldContent('content'); ?>

<!--    -->
<!--Footer-->
<!--    -->
<?php echo $__env->yieldContent('footer'); ?>


<script src="<?php echo e(asset('asset/site/js-plugins/jquery-3.5.1.min.js'), false); ?>"></script>
<script src="<?php echo e(asset('asset/site/js-plugins/stellarnav.min.js'), false); ?>"></script>
<script src="<?php echo e($assetPath, false); ?>/js-plugins/zoom.js"></script>
<script src="<?php echo e(asset('asset/site/js-plugins/my-code.js'), false); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>

<?php /**PATH D:\OpenServer\domains\investments\resources\views/layouts/site.blade.php ENDPATH**/ ?>