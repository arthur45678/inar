


<?php $__env->startSection('styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('site.includes.info-box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="buisness">

        <div class="left-container">
            <?php if(!empty($post->page_img) && isset($post->page_img)): ?> 
                <img src="<?php echo e(showImage($post->page_img), false); ?>" alt="<?php echo e($post->name, false); ?>" class="zoom" />

            <?php endif; ?>
        </div>
        <div class="right-container">
            <div class="page-name"><?php echo e($post->name, false); ?></div>
            <?php if(!empty($post->page_img_mini) && isset($post->page_img_mini)): ?>
                <img src="<?php echo e(showImage($post->page_img_mini), false); ?>" alt="<?php echo e($post->name, false); ?>" />

            <?php endif; ?>
        </div>
    </div>
    <div class="page-link">
        <span class="first"><?php echo e($post->name, false); ?></span>

    </div>

    <div class="main-info">
        <?php if(!empty($post->text_top) && isset($post->text_top)): ?> 
            <div class="info-right">
                <div><?php echo $post->text_top; ?></div>
                <img src="<?php echo e($assetPath, false); ?>/css/icons-images/mission-fon.svg" alt="fon" />
            </div>
        <?php endif; ?>
        <?php if(!empty($post->page_img_top) && isset($post->page_img_top)): ?>
            <div style="background-image:url(<?php echo e(showImage($post->page_img_top), false); ?>)" class="main-justify back">
        <?php endif; ?>
        </div>
<!--Square menu items-->

                <div class="our-mission">
                    <div class="mission-containers">
                        <?php if(!empty($post->service_icon_symbol_1) && isset($post->service_icon_symbol_1)): ?> 
                            <div>
                                <img src="<?php echo e(showImage($post->service_icon_symbol_1), false); ?>" alt="<?php echo e($post->service_name_1, false); ?>" />
                                <div class="values">
                                    <div><?php echo e($post->service_name_1, false); ?></div>
                                    <div><?php echo e($post->service_price_1, false); ?></div>
                                </div>
                            </div>
                        <?php endif; ?>
                            <?php if(!empty($post->service_icon_symbol_2) && isset($post->service_icon_symbol_2)): ?>
                                <div class="mission_center">
                                    <img src="<?php echo e(showImage($post->service_icon_symbol_2), false); ?>" alt="<?php echo e($post->service_name_2, false); ?>" />
                                    <div class="values">
                                        <div><?php echo e($post->service_name_2, false); ?></div>
                                        <div><?php echo e($post->service_price_2, false); ?></div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if(!empty($post->service_icon_symbol_3) && isset($post->service_icon_symbol_3)): ?>
                                <div>
                                    <img src="<?php echo e(showImage($post->service_icon_symbol_3), false); ?>" alt="<?php echo e($post->service_name_3, false); ?>" />
                                    <div class="values">
                                        <div><?php echo e($post->service_name_3, false); ?></div>
                                        <div><?php echo e($post->service_price_3, false); ?></div>
                                    </div>
                                </div>
                            <?php endif; ?>
                    </div>
                    <div class="mission-containers">
                        <?php if(!empty($post->service_icon_symbol_4) && isset($post->service_icon_symbol_4)): ?>
                            <div>
                                <img src="<?php echo e(showImage($post->service_icon_symbol_4), false); ?>" alt="<?php echo e($post->service_name_4, false); ?>" />
                                <div class="values">
                                    <div><?php echo e($post->service_name_4, false); ?></div>
                                    <div><?php echo e($post->service_price_4, false); ?></div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if(!empty($post->service_icon_symbol_5) && isset($post->service_icon_symbol_5)): ?>
                            <div class="mission_center">
                                <img src="<?php echo e(showImage($post->service_icon_symbol_5), false); ?>" alt="<?php echo e($post->service_name_5, false); ?>" />
                                <div class="values">
                                    <div><?php echo e($post->service_name_5, false); ?></div>
                                    <div><?php echo e($post->service_price_5, false); ?></div>
                                </div>
                            </div>
                        <?php endif; ?>

                            <?php if(!empty($post->service_icon_symbol_6) && isset($post->service_icon_symbol_6)): ?>
                                <div>
                                    <img src="<?php echo e(showImage($post->service_icon_symbol_5), false); ?>" alt="<?php echo e($post->service_name_5, false); ?>" />
                                    <div class="values">
                                        <div><?php echo e($post->service_name_6, false); ?></div>
                                        <div><?php echo e($post->service_price_6, false); ?></div>
                                    </div>
                                </div>
                            <?php endif; ?>

                    </div>
                </div>
<!--End Square menu items-->
            <?php if(!empty($post->page_img_bottom) && isset($post->page_img_bottom)): ?>
                <div style="background-image:url(<?php echo e(showImage($post->page_img_bottom), false); ?>)" class="main-justify back"></div>
            <?php endif; ?>

        <div class="info-left">
            <!-- <img src="<?php echo e($assetPath, false); ?>/css/icons-images/mission-fon.svg" alt="fon" /> -->
            <div><?php echo $post->text_middle; ?></div>
        </div>
            <!-- <?php if(!empty($post->page_img_middle) && isset($post->page_img_middle)): ?>
                <div style="background-image:url(<?php echo e(showImage($post->page_img_middle), false); ?>)" class="main-justify back "></div>

            <?php endif; ?> -->



            <?php if(!empty($post->text_bottom) && isset($post->text_bottom)): ?>
                <div class="main-info-enviroment talent mr-auto no-center">
                    <div><?php echo $post->text_bottom; ?></div>
                    <!-- <img src="<?php echo e($assetPath, false); ?>/css/icons-images/mission-fon.svg" alt="fon" /> -->
                </div>
            <?php endif; ?>




<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('site.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\investments\resources\views/site/pages/qualities/show.blade.php ENDPATH**/ ?>