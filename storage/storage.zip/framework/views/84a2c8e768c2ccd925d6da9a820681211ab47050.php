

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.info-box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>

        <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
            <div class="container">
                <div class="page-header-content pt-4">
                    <div class="row align-items-center justify-content-between">
                        <div class="col-auto mt-4">
                            <h1 class="page-header-title">
                                <div class="page-header-icon"><i data-feather="filter"></i></div>
                                <?php echo e($title, false); ?>

                            </h1>
                        </div>
                    </div>
                </div>
            </div>
        </header>


        <!-- Main page content-->
        <div class="container mt-n10">
            <div class="card mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e($title, false); ?></h6>
                </div>

                <div class="card-body">
                    <form method="post" action="<?php echo e(route('admin.articles.store'), false); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        
                        <div class="form-group">
                            <label for="img">Նկար</label>
                            <input name="img" id="img" type="file" class="form-control filestyle" data-buttonName="btn-primary">
                        </div>

                        <div class="form-group">
                            <label for="img_mini">Փոքր նկար</label>
                            <input name="img_mini" id="img_mini" type="file" class="form-control filestyle" data-buttonName="btn-primary">
                        </div>

                        
                        <div class="form-group after-add-more">
                            <div class="input-group-btn">
                                <button class="btn btn-success add-more" type="button"><i class="glyphicon glyphicon-plus"></i>Կցել չարտ</button>
                            </div>
                        </div>


                        <?php if($charts->count() > 0): ?>
                            <div class="form-group">
                                <div class="copy d-none">
                                    <div class="control-group input-group" style="margin-top:10px">
                                        <div class="input-group-btn">
                                            <?php $__currentLoopData = $charts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <button class="btn btn-danger remove" type="button"><i class="glyphicon glyphicon-remove"></i>Ջնջել</button>
                                            <label for="<?php echo e($item->id, false); ?>"><?php echo e(showTranslationsNameAllLanguage($item, 'name'), false); ?></label>
                                            <input type="checkbox" name="" value="">

                                            <label for="charts">Ընտրել տեղը</label>
                                            <select name="chart_position[]" id="chart_position" class="form-control">
                                                <option value="<?php echo e(\App\Models\Chart::POSITION_TOP, false); ?>">Վերևում</option>
                                                <option value="<?php echo e(\App\Models\Chart::POSITION_LEFT, false); ?>">Ներքևում</option>
                                                <option value="<?php echo e(\App\Models\Chart::POSITION_RIGHT, false); ?>">Աջ</option>
                                                <option value="<?php echo e(\App\Models\Chart::POSITION_BOTTOM, false); ?>">Ձախ</option>
                                            </select>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php endif; ?>



                        <div class="form-group">
                            <label for="tags">Թեգեր</label>
                            <select name="tags[]" id="tags" class="select2 form-control"  multiple="multiple">
                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id, false); ?>"><?php echo e(showTranslationsNameAllLanguage($item, 'name'), false); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="categories">Բաժիններ</label>
                            <select name="categories[]" id="categories" class="select2 form-control"  multiple="multiple">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id, false); ?>"><?php echo e(showTranslationsNameAllLanguage($item, 'name'), false); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>


                        


                        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                            <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item" role="<?php echo e($localeCode, false); ?>">
                                    <a class="nav-link <?php echo e((App::getLocale() ==  $localeCode) ? 'active' : '', false); ?>" id="pills-home-tab" data-toggle="pill" href="#tab_<?php echo e($localeCode, false); ?>" aria-controls="<?php echo e($localeCode, false); ?>" aria-selected="true"><?php echo e($properties['native'], false); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class="tab-content" id="pills-tabContent">
                            <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane fade show <?php echo e((App::getLocale() ==  $localeCode) ? 'active' : '', false); ?>" id="tab_<?php echo e($localeCode, false); ?>" role="<?php echo e($localeCode, false); ?>" aria-labelledby="pills-home-tab">
                                    <div class="form-group">
                                        <label for="<?php echo e($localeCode, false); ?>[title]">Վերնագիր</label>
                                        <input type="text" name="name[<?php echo e($localeCode, false); ?>]" id="<?php echo e($localeCode, false); ?>[title]" value="" class="form-control">
                                    </div>

                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="desc[<?php echo e($localeCode, false); ?>]">Կարճ տեքստ</label>
                                                <textarea name="desc[<?php echo e($localeCode, false); ?>]" id="desc[<?php echo e($localeCode, false); ?>]" cols="15" rows=4" class="form-control"></textarea>
                                            </div>
                                        </div>
                                    </div><!--row-->

                                    <textarea id="my-editor-<?php echo e($localeCode, false); ?>" name="text[<?php echo e($localeCode, false); ?>]" class="ck-editor-run form-control"></textarea>
                                    <script>
                                        var options = {
                                            filebrowserImageBrowseUrl: '/laravel-filemanager?type=Images',
                                            filebrowserImageUploadUrl: '/laravel-filemanager/upload?type=Images&_token=',
                                            filebrowserBrowseUrl: '/laravel-filemanager?type=Files',
                                            filebrowserUploadUrl: '/laravel-filemanager/upload?type=Files&_token='
                                        };
                                    </script>

                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="meta_desc[<?php echo e($localeCode, false); ?>]">Մետա տեքստ</label>
                                                <textarea name="meta_desc[<?php echo e($localeCode, false); ?>]" id="meta_desc[<?php echo e($localeCode, false); ?>]" cols="15" rows=4" class="form-control"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="keywords[<?php echo e($localeCode, false); ?>]">Բանալի բառեր</label>
                                                <textarea name="keywords[<?php echo e($localeCode, false); ?>]" id="keywords[<?php echo e($localeCode, false); ?>]" cols="15" rows="4" class="form-control"></textarea>
                                            </div>
                                        </div>
                                    </div><!--row-->


                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">Ավելացնել</button>
                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </form>

                </div>

            </div>

        </div>
    </main>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\investments\resources\views/admin/articles/create.blade.php ENDPATH**/ ?>