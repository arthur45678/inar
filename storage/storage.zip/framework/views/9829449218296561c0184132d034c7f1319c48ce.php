


<?php $__env->startSection('styles'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('asset/login/login.css'), false); ?>"/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('header'); ?>
    <?php
    $rows = \App\Models\Menu::getMenus(\Illuminate\Support\Facades\App::getLocale());
    $menu_tree = \App\Models\Menu::buildTreeForSelectMultiLevel($rows); ?>
    <?php echo $__env->make('site.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="login-container">


            <form method="POST" action="<?php echo e(route('login'), false); ?>">
                <?php echo csrf_field(); ?>
            <h1><?php echo e(__('Login'), false); ?></h1>
            <label for="email" class="log"><?php echo e(__('E-Mail Address'), false); ?></label>
            <input placeholder="Մուտքանունը"  id="email" type="email" class=" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email'), false); ?>" required autocomplete="email" autofocus/>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message, false); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="parol">

                <label for="passwords" class="pass"><?php echo e(__('Password'), false); ?></label>
                <?php if(Route::has('password.request')): ?>
                    <span><a  href="<?php echo e(route('password.request'), false); ?>">
                        <?php echo e(__('Forgot Your Password?'), false); ?>

                    </a>
                    </span>
                <?php endif; ?>
            </div>
            <input type="password" placeholder="Գաղտնաբառը" id="passwords" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   name="password" required autocomplete="current-password"/>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message, false); ?></strong>
             </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="check">
                <div>

                    <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : '', false); ?>>

                    <label for="remember">
                        <?php echo e(__('Remember Me'), false); ?>

                    </label>
                </div>
                <button><?php echo e(__('Login'), false); ?></button>
            </div>
            </form>


    </div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('site.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\investments\resources\views/auth/login.blade.php ENDPATH**/ ?>