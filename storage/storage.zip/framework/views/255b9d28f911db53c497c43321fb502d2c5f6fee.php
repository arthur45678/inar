<nav class="sidenav shadow-right sidenav-light">
    <div class="sidenav-menu">
        <div class="nav accordion" id="accordionSidenav">

            
            <div class="sidenav-menu-heading">Կարգավորումներ</div>
            <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                <div class="nav-link-icon"><i data-feather="layout"></i></div>
                Կարգավորումներ
                <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse" id="collapseLayouts" data-parent="#accordionSidenav">
                <nav class="sidenav-menu-nested nav accordion" id="accordionSidenavLayout">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings-create')): ?>
                        <a class="nav-link" href="<?php echo e(route('admin.settings.generalSettings'), false); ?>">Գլխավոր կարգավորումները</a>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-list')): ?>
                        <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-role7" aria-expanded="false" aria-controls="collapse-role7">
                            Դերեր
                            <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapse-role7" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.roles.index'), false); ?>">
                                    Բոլոր դերերը
                                </a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu-create')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.roles.create'), false); ?>">Ավելացնել դեր</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu-list')): ?>
                        <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse--footerBottomMenu77" aria-expanded="false" aria-controls="collapse--footerBottomMenu77">
                            Մենյու
                            <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapse--footerBottomMenu77" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.menus.index'), false); ?>">
                                    Բոլոր հղումները
                                </a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu-create')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.menus.selectLanguage'), false); ?>">Ավելացնել նոր հղում</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>

                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu-list')): ?>
                        <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-menu_top" aria-expanded="false" aria-controls="collapse-menu_top">
                            Ներքևի Մենյու (ներքևի հատված)
                            <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapse-menu_top" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.footerBottomMenus.index'), false); ?>">
                                    Ներքևի Մենյու (ներքևի հատված)
                                </a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu-create')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.footerBottomMenus.selectLanguage'), false); ?>">Ավելացնել նոր հղում</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu-list')): ?>
                        <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-footerSocialLinksMenus77" aria-expanded="false" aria-controls="collapse-footerSocialLinksMenus77">
                            Ներքևի Մենյու (սոցիալական ցանցի հղումներ)
                            <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapse-footerSocialLinksMenus77" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.footerSocialLinksMenus.index'), false); ?>">
                                    Բոլոր հղումները
                                </a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu-create')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.footerSocialLinksMenus.selectLanguage'), false); ?>">Ավելացնել նոր հղում</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>
                </nav>
            </div>

            

            <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-homePages" aria-expanded="false" aria-controls="collapse-homePages">
                <div class="nav-link-icon"><i data-feather="layout"></i></div>
                Գլխավոր էջ
                <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse" id="collapse-homePages" data-parent="#accordionSidenav">
                <nav class="sidenav-menu-nested nav accordion" id="accordionSidenavLayout">
                    <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-sliders" aria-expanded="false" aria-controls="collapse-sliders">
                        Սլայդեր
                        <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sliders-list')): ?>
                        <div class="collapse" id="collapse-sliders" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.sliders.index'), false); ?>">Բոլոր սլայդերը</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sliders-create')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.sliders.create'), false); ?>">Նոր սլայդ</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>

                    <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-ourMissionsMenu" aria-expanded="false" aria-controls="collapse-ourMissionsMenu">
                        Մեր առաքելությունը մենյու
                        <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu-list')): ?>
                        <div class="collapse" id="collapse-ourMissionsMenu" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.home.ourMissionsMenus.index'), false); ?>">Բոլորը</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu-create')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.home.ourMissionsMenus.selectLanguage'), false); ?>">Ավելացնել</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>

                    <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-discovery-armenia" aria-expanded="false" aria-controls="collapse-discovery-armenia">
                        Բացահայտել Հայաստանը
                        <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu-list')): ?>
                        <div class="collapse" id="collapse-discovery-armenia" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.home.discovery-armenia.index'), false); ?>">Բոլորը</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu-create')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.home.discovery-armenia.create'), false); ?>">Ավելացնել</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>


                </nav>
            </div>


            

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tags-list')): ?>
                <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapseTags" aria-expanded="false" aria-controls="collapseTags">
                    <div class="nav-link-icon"><i data-feather="tool"></i></div>
                    Թեգեր
                    <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseTags" data-parent="#accordionSidenav">
                    <nav class="sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('admin.tags.index'), false); ?>">Բոլոր թեգերը</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tags-create')): ?>
                            <a class="nav-link" href="<?php echo e(route('admin.tags.create'), false); ?>">
                                Ավելացնել թեգ
                            </a>
                        <?php endif; ?>
                    </nav>
                </div>
            <?php endif; ?>
            
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('categories-list')): ?>
                <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-categories" aria-expanded="false" aria-controls="collapse-categories">
                    <div class="nav-link-icon"><i data-feather="tool"></i></div>
                    Բաժիններ
                    <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapse-categories" data-parent="#accordionSidenav">
                    <nav class="sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('admin.categories.index'), false); ?>">Բոլոր բաժինները</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('categories-create')): ?>
                            <a class="nav-link" href="<?php echo e(route('admin.categories.create'), false); ?>">
                                Ավելացնել բաժին
                            </a>
                        <?php endif; ?>
                    </nav>
                </div>
            <?php endif; ?>
            


            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-posts" aria-expanded="false" aria-controls="collapse-posts">
                    <div class="nav-link-icon"><i data-feather="tool"></i></div>
                    Նորություններ
                    <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapse-posts" data-parent="#accordionSidenav">
                    <nav class="sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('admin.articles.index'), false); ?>">Բոլորը</a>
                        <a class="nav-link" href="<?php echo e(route('newsPage'), false); ?>">Գլխավոր նորությունները</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-create')): ?>
                            <a class="nav-link" href="<?php echo e(route('admin.articles.create'), false); ?>">
                                Ավելացնել
                            </a>
                        <?php endif; ?>
                    </nav>
                </div>
            <?php endif; ?>
            


            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-events" aria-expanded="false" aria-controls="collapse-events">
                    <div class="nav-link-icon"><i data-feather="tool"></i></div>
                    Միջոցառումներ
                    <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapse-events" data-parent="#accordionSidenav">
                    <nav class="sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('admin.events.index'), false); ?>">Բոլոր միջոցառումները</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-create')): ?>
                            <a class="nav-link" href="<?php echo e(route('admin.events.create'), false); ?>">
                                Ավելացնել Միջոցառում
                            </a>
                        <?php endif; ?>
                    </nav>
                </div>
            <?php endif; ?>
            


            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-list')): ?>
                <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-user" aria-expanded="false" aria-controls="collapse-user">
                    <div class="nav-link-icon"><i data-feather="tool"></i></div>
                    Ադմիններ
                    <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapse-user" data-parent="#accordionSidenav">
                    <nav class="sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('admin.users.index'), false); ?>">Բոլոր ադմինները</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
                            <a class="nav-link" href="<?php echo e(route('admin.users.create'), false); ?>">
                                Նոր ադմին
                            </a>
                        <?php endif; ?>
                    </nav>
                </div>
            <?php endif; ?>
            



            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('managers-list')): ?>
                <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-managers" aria-expanded="false" aria-controls="collapse-managers">
                    <div class="nav-link-icon"><i data-feather="tool"></i></div>
                    Մենեջերներ
                    <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapse-managers" data-parent="#accordionSidenav">
                    <nav class="sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('admin.managers.index'), false); ?>">Բոլոր մենեջերները</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('managers-create')): ?>
                            <a class="nav-link" href="<?php echo e(route('admin.managers.create'), false); ?>">
                                Նոր մենեջեր
                            </a>
                        <?php endif; ?>
                    </nav>
                </div>
            <?php endif; ?>
            

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('investors-list')): ?>
                <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-investors" aria-expanded="false" aria-controls="collapse-investors">
                    <div class="nav-link-icon"><i data-feather="tool"></i></div>
                    Ներդրողներ
                    <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapse-investors" data-parent="#accordionSidenav">
                    <nav class="sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('admin.investors.index'), false); ?>">Բոլոր ներդրողները</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('investors-create')): ?>
                            <a class="nav-link" href="<?php echo e(route('admin.investors.create'), false); ?>">
                                Նոր ներդրող
                            </a>
                        <?php endif; ?>
                    </nav>
                </div>
            <?php endif; ?>
            



            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notifications-view')): ?>
                <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-notifications" aria-expanded="false" aria-controls="collapse-notifications">
                    <div class="nav-link-icon"><i data-feather="tool"></i></div>
                    Ծանուցումներ
                    <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapse-notifications" data-parent="#accordionSidenav">
                    <nav class="sidenav-menu-nested nav">
                        <a class="nav-link" href="<?php echo e(route('admin.notifications.index'), false); ?>">Բոլորը</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notifications-create')): ?>
                            <a class="nav-link" href="<?php echo e(route('admin.notifications.sendNotification'), false); ?>">
                                Ուղարկել ծանուցում
                            </a>
                        <?php endif; ?>
                    </nav>
                </div>
            <?php endif; ?>
            


            <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-pages" aria-expanded="false" aria-controls="collapse-pages">
                <div class="nav-link-icon"><i data-feather="layout"></i></div>
                էջեր
                <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
            </a>
            <div class="collapse" id="collapse-pages" data-parent="#accordionSidenav">
                <nav class="sidenav-menu-nested nav accordion" id="accordionSidenavLayout">
                    <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-pages-simples" aria-expanded="false" aria-controls="collapse-pages-simples">
                        Սովորական էջ
                        <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                        <div class="collapse" id="collapse-pages-simples" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.pages.simples.index'), false); ?>">Բոլորը</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.pages.simples.create'), false); ?>">Ավելացնել</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>

                    <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-pages-simples-2" aria-expanded="false" aria-controls="collapse-pages-simples">
                        Սովորական էջ 2
                        <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                        <div class="collapse" id="collapse-pages-simples-2" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.pages.simples-2.index'), false); ?>">Բոլորը</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.pages.simples-2.create'), false); ?>">Ավելացնել</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>


                    <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-pages-qualities" aria-expanded="false" aria-controls="collapse-pages-qualities">
                        Որակի էջ
                        <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                        <div class="collapse" id="collapse-pages-qualities" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.pages.qualities.index'), false); ?>">Բոլորը</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.pages.qualities.create'), false); ?>">Ավելացնել</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>

                    <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-pages-pageinnovations" aria-expanded="false" aria-controls="collapse-pages-pageinnovations">
                        Իննովացիոն էջ
                        <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                        <div class="collapse" id="collapse-pages-pageinnovations" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.pages.pageinnovations.index'), false); ?>">Բոլորը</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.pages.pageinnovations.create'), false); ?>">Ավելացնել</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>

                    <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-pages-aboutusDepartment" aria-expanded="false" aria-controls="collapse-pages-aboutusDepartment">
                        Մեր մասին (աշխատակիցներ բաժանմունք)
                        <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                        <div class="collapse" id="collapse-pages-aboutusDepartment" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.pages.aboutusDepartment.index'), false); ?>">Բոլորը</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.pages.aboutusDepartment.create'), false); ?>">Ավելացնել</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>

                    <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-pages-aboutus" aria-expanded="false" aria-controls="collapse-pages-aboutus">
                        Մեր մասին
                        <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                        <div class="collapse" id="collapse-pages-aboutus" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.pages.aboutus.index'), false); ?>">Բոլորը</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.pages.aboutus.create'), false); ?>">Ավելացնել</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>

                    <a class="nav-link collapsed" href="javascript:void(0);" data-toggle="collapse" data-target="#collapse-pages-talents" aria-expanded="false" aria-controls="collapse-pages-talents">
                        Տաղանդ էջ
                        <div class="sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                        <div class="collapse" id="collapse-pages-talents" data-parent="#accordionSidenavLayout">
                            <nav class="sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('admin.pages.talents.index'), false); ?>">Բոլորը</a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts-list')): ?>
                                    <a class="nav-link" href="<?php echo e(route('admin.pages.talents.create'), false); ?>">Ավելացնել</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>
                </nav>
            </div>


            
            <a class="nav-link" href="<?php echo e(route('admin.charts.index'), false); ?>">
                <div class="nav-link-icon"><i data-feather="bar-chart"></i></div>
                Գրաֆիկներ
            </a>
            <a class="nav-link" href="<?php echo e(route('admin.map.index'), false); ?>">
                <div class="nav-link-icon"><i data-feather="map"></i></div>
                Քարտեզ
            </a>
            <a class="nav-link" href="<?php echo e(route('admin.region.index'), false); ?>">
                <div class="nav-link-icon"><i data-feather="filter"></i></div>
                Մարզեր
            </a>
            <a class="nav-link" href="<?php echo e(route('admin.calendar.index'), false); ?>"  >
                <div class="nav-link-icon"><i data-feather="grid"></i></div>
                Օրացույց

            </a>
        </div>
    </div>
    <div class="sidenav-footer">
        <!-- <div class="sidenav-footer-content">
            <div class="sidenav-footer-subtitle">Logged in as:</div>
            <div class="sidenav-footer-title">Valerie Luna</div>
        </div> -->
    </div>
</nav>
<?php /**PATH D:\OpenServer\domains\investments\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>