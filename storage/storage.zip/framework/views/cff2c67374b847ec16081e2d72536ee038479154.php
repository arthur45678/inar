<footer>
    <div class="footer">
        <div class="flex-img">
            <div class="first-img"><img src="<?php echo e(asset('asset/site/css/icons-images/gerb.png'), false); ?>" alt="" /></div>
            <div class="second-img"><img src="<?php echo e(asset('asset/site/css/icons-images/logo.svg'), false); ?>" alt="" /></div>
        </div>
        <div class="flex-info">
            <div>
                <ul class="ul-top">
                    <?php if(isset($footerMenusTop) && $footerMenusTop->count() > 0): ?>
                        <?php $__currentLoopData = $footerMenusTop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e($item->path, false); ?>"><?php echo e($item->title, false); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </ul>
                <ul class="ul-bottom">
                    <?php if(isset($footerMenusBottom) && $footerMenusBottom->count() > 0): ?>
                        <?php $__currentLoopData = $footerMenusBottom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e($item->path, false); ?>"><?php echo e($item->title, false); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <li>
                        <ul class="flex-icons">
                            <li><a href="#"><img src="<?php echo e(asset('asset/site/css/icons-images/linkedin.svg'), false); ?>" alt="linkedin" /></a></li>
                            <li><a href="#"><img src="<?php echo e(asset('asset/site/css/icons-images/facebook.svg'), false); ?>" alt="facebook" /></a></li>
                            <li><a href="#"><img src="<?php echo e(asset('asset/site/css/icons-images/instagram.svg'), false); ?>" alt="instagram" /></a></li>
                            <li><a href="#"><img src="<?php echo e(asset('asset/site/css/icons-images/twitter.svg'), false); ?>" alt="twitter" /></a></li>
                        </ul>
                    </li>
                    <li><button class="subscribe">subscribe</button></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\OpenServer\domains\investments\resources\views/site/includes/footer.blade.php ENDPATH**/ ?>