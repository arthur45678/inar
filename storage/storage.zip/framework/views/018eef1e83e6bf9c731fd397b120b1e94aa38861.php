


<?php $__env->startSection('styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('site.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('site.includes.info-box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="general-container">
        <div class="norut-anun">News</div>
        <img src="<?php echo e($assetPath, false); ?>/css/icons-images/News-and-events-cover.jpg" alt="news" />
    </div>
    <div class="page-link">
        <span class="first">News and Events</span>
        <span><a href="#">News</a></span>
    </div>
    <div class="news-container">
        <div class="left-news">
            <?php if(isset($lastPost)): ?>
                <div>
                    <p class="left-news-title"><?php echo e($lastPost->name, false); ?></p>
                </div>
                <a href="<?php echo e(route('articles.show',$lastPost->slug ), false); ?>">
                    <?php if($lastPost->img): ?>
                        <img src="<?php echo e(showImage($lastPost->img), false); ?>" alt="router" /></a>
                    <?php endif; ?>

                <div class="left-news-txt">
                    <?php echo e($lastPost->desc, false); ?>

                </div>
                <div class="right">
                    <a href="<?php echo e(route('articles.show',$lastPost->slug ), false); ?>" class="read-more">Read more</a>
                </div>
            <?php endif; ?>

        </div>
        <div class="right-news">
            <div class="pop">
                <span>MOST POPULAR</span>
            </div>
 
            <?php if(isset($mosPopularPosts) && $mosPopularPosts->count() > 0 ): ?>
                
            <?php for($i = 0; $i < count($mosPopularPosts); $i++): ?>

                    <div class="right-news-img">
                        <div><?php echo e(showDateWithMonthName($mosPopularPosts[$i]->created_at), false); ?></div>
                        <a href="<?php echo e(route('articles.show',$mosPopularPosts[$i]->slug ), false); ?>">
                            <img src="<?php echo e(showImage($mosPopularPosts[$i]->img_mini), false); ?>" alt="<?php echo e($mosPopularPosts[$i]->name, false); ?>" />
                        </a>
                        <p class="right-news-title"><a href="<?php echo e(route('articles.show',$mosPopularPosts[$i]->slug ), false); ?>"><?php echo e($mosPopularPosts[$i]->name, false); ?></a> </p>
                        <p class="right-news-txt"><?php echo e(Str::limit($mosPopularPosts[$i]->desc,200), false); ?></p>
                    </div>
            <?php endfor; ?>


            <?php endif; ?>


        </div>
    </div>
    <div class="posts">
        <div class="pop">
            <span>MOST POPULAR</span>
            <div class="all"><a href="<?php echo e(route('articles.index'), false); ?>">All posts</a></div>
        </div>
        <div class="post-items">
            <?php if(isset($mosPopularPosts) && $mosPopularPosts->count() > 2 ): ?>
                <?php for($i = 2; $i < 5; $i++): ?>
                    <?php if(isset($mosPopularPosts[$i])): ?>
                        <div>

                            <div class="right-news-img">

                                <div class="data-post"><?php echo e(showDateWithMonthName($mosPopularPosts[$i]->created_at), false); ?></div>
                                <?php if(isset($mosPopularPosts[$i]->img_mini)): ?>
                                    <a href="<?php echo e(route('articles.show',$mosPopularPosts[$i]->slug ), false); ?>">
                                        <img src="<?php echo e(showImage($mosPopularPosts[$i]->img_mini), false); ?>" alt="<?php echo e($mosPopularPosts[$i]->name, false); ?>" />
                                    </a>
                                <?php endif; ?>

                            </div>
                            <p class="right-news-txt"><a href="<?php echo e(route('articles.show',$mosPopularPosts[$i]->slug ), false); ?>"><?php echo e($mosPopularPosts[$i]->name, false); ?></a></p>
                        </div>

                    <?php endif; ?>

                <?php endfor; ?>

            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('site.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\investments\resources\views/site/articles/newsPage.blade.php ENDPATH**/ ?>